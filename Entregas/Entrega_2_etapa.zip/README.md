##Projeto Linguagem de Programação
 
Compilador para Mini Java.

## Compilar

```
gcc CompiladorMiniJava.c -o CompiladorMiniJava.out
```

##Documentação

O executável consome o arquivo file.txt que deve estar localizado no mesmo diretório. A execução do mesmo, deve gerar um arquivo chamado token.txt

```
./CompiladorMiniJava.out
```
